// config.js

module.exports = {
    development: {
        username: 'root',
        password: '',
        database: 'mytestapp',
        host: '127.0.0.1',
        dialect: 'mysql',
    },
    // Add other environments as needed (e.g., production, testing)
};
