const jwt = require('jsonwebtoken');

const authenticateToken = async (req, res, next) => {

try {
  const token = req.body.token || req.query.token || req.headers["x-access-token"] || req.headers["authorization"];

  if (!token) {
    return res.status(403).json({ status: 401, message: 'A token is required for authentication' });
  }
  const tokenWithoutBearer = token.replace(/^Bearer\s+/i, '');

  const decoded = await jwt.verify(tokenWithoutBearer, process.env.JWT_SECRET);

  req.user = decoded;
  next();
} catch (err) {
  if (err.status === 401) {
      return res.status(401).send({ status: 401, message: err.message });
  } else {
      return res.status(400).send({ statusCode: 0, message: err.toString() });
  }
}
};

module.exports = { authenticateToken };