module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    mobile: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        is: /^[0-9]{10}$/
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    address: {
      type: DataTypes.STRING,
    },
    latitude: {
      type: DataTypes.FLOAT,
    },
    longitude: {
      type: DataTypes.FLOAT,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      }
    },
    resetOtp: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    resetOtpExpiration: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  });

  
  User.associate = (models) => {
    User.hasMany(models.FriendRequest, { as: 'SentRequests', foreignKey: 'senderId' });
    User.hasMany(models.FriendRequest, { as: 'ReceivedRequests', foreignKey: 'receiverId' });
    User.belongsToMany(models.User, {
      as: 'Friends',
      through: 'Friendship',
      foreignKey: 'userId',
      otherKey: 'friendId'
    });
  };
  return User;
};
