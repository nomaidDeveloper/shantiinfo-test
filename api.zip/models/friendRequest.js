module.exports = (sequelize, DataTypes) => {
  const FriendRequest = sequelize.define('FriendRequest', {
    senderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    receiverId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM('pending', 'accepted', 'rejected'),
      defaultValue: 'pending',
    },
  });

  FriendRequest.associate = (models) => {
    FriendRequest.belongsTo(models.User, { as: 'Sender', foreignKey: 'senderId' });
    FriendRequest.belongsTo(models.User, { as: 'Receiver', foreignKey: 'receiverId' });
  };

  return FriendRequest;
};
