const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/login', authController.signIn);
router.post('/refresh-token', authController.refreshToken);
router.post('/forgot-password', authController.requestPasswordReset);
router.post('/reset-password', authController.resetPassword);
router.post('/register', authController.signUp);

module.exports = router;