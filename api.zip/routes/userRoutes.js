// const express = require('express');
// const router = express.Router();
// const userController = require('../controllers/userController');
// const { authenticateToken } = require('../middleware/auth');

// router.put('/updateUser', authenticateToken, userController.updateProfile);
// router.get('/search', authenticateToken, userController.searchFriends);
// router.get('/friends', authenticateToken, userController.getFriendList);
// router.delete('/friends/:friendId', authenticateToken, userController.removeFriend);
// router.get('/friend-requests', authenticateToken, userController.getFriendRequests);
// router.post('/friend-requests/:requestId/accept', authenticateToken, userController.acceptFriendRequest);
// router.post('/friend-requests/:requestId/reject', authenticateToken, userController.rejectFriendRequest);
// router.get('/profile/:userId', authenticateToken, userController.viewProfile);
// router.post('/friend-requests/:friendId', authenticateToken, userController.sendFriendRequest);

// module.exports = router;

const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateToken } = require('../middleware/auth');

// Routes
router.get('/getUser/:userId', authenticateToken, userController.viewProfile);
router.put('/updateUser', authenticateToken, userController.updateProfile);
router.get('/search', authenticateToken, userController.searchFriends);
router.get('/friends', authenticateToken, userController.getFriendList);
router.delete('/friends/:friendId', authenticateToken, userController.removeFriend);
router.get('/friend-requests', authenticateToken, userController.getFriendRequests);
router.post('/friend-requests/:requestId/accept', authenticateToken, userController.acceptFriendRequest);
router.post('/friend-requests/:requestId/reject', authenticateToken, userController.rejectFriendRequest);
router.post('/friend-requests/:friendId', authenticateToken, userController.sendFriendRequest);

module.exports = router;
