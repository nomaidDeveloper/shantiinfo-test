import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import FriendSearch from "./pages/FriendSearch";
import FriendList from "./pages/FriendList";
import FriendRequests from "./pages/FriendRequests";
import Home from "./pages/Home";
import ProtectedRoute from "./components/ProtectedRoutes";
import ForgotPassword from "./pages/ForgotPassword";

const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/forgotpassword",
    element: <ForgotPassword />,
  },
  {
    path: "/signup",
    element: <Register />,
  },
  {
    path: "/",
    element: <ProtectedRoute><Home /></ProtectedRoute>,
  },
  {
    path: "/profile/:userId",
    element: <ProtectedRoute><Profile /></ProtectedRoute>,
  },
  {
    path: "/search",
    element: <ProtectedRoute><FriendSearch /></ProtectedRoute>,
  },
  {
    path: "/friends",
    element: <ProtectedRoute><FriendList /></ProtectedRoute>,
  },
  {
    path: "/requests",
    element: <ProtectedRoute><FriendRequests /></ProtectedRoute>,
  },
]);
function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;