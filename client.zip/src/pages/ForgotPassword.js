import React, { useState } from 'react';
import instance from '../api/axios';
import { toast, ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
const ForgotPassword = () => {
    const navigate = useNavigate();

    const [step, setStep] = useState('forgot'); // 'forgot' or 'reset'
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleForgotSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await instance.post('/api/auth/forgot-password', { email });
            setMessage(response.data.message);
            setError('');
            setStep('reset'); // Move to reset step
        } catch (err) {
            setError(err.response?.data?.message || 'Server error');
            setMessage('');
        }
    };

    const handleResetSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await instance.post('/api/auth/reset-password', { email, otp, newPassword });
            console.log(response,"response");
            
            if (response.data.statusCode == 200) {
                toast.success("Successfully reset password");
                navigate(`/login`);

            }
            setMessage(response.data.message);
            setError('');
        } catch (err) {
            setError(err.response?.data?.message || 'Server error');
            setMessage('');
        }
    };

    return (
        <div className="password-management-container">
            {step === 'forgot' ? (
                <div className="forgot-password">
                    <h2>Forgot Password</h2>
                    <form onSubmit={handleForgotSubmit}>
                        <div>
                            <label>Email:</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit">Request Reset</button>
                    </form>
                </div>
            ) : (
                <div className="reset-password">
                    <h2>Reset Password</h2>
                    <form onSubmit={handleResetSubmit}>
                        <div>
                            <label>Email:</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label>OTP:</label>
                            <input
                                type="text"
                                value={otp}
                                onChange={(e) => setOtp(e.target.value)}
                                required
                            />
                        </div>
                        <div>
                            <label>New Password:</label>
                            <input
                                type="password"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit">Reset Password</button>
                    </form>
                </div>
            )}
            {message && <div className="message">{message}</div>}
            {error && <div className="error">{error}</div>}
            <ToastContainer />
        </div>
    );
};

export default ForgotPassword;
