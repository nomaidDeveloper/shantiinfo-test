import React, { useState, useEffect } from 'react';
import instance from '../api/axios'; 


function FriendList() {
  const [friends, setFriends] = useState([]);

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        const response = await instance.get('api/user/friends', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        setFriends(response.data);
      } catch (error) {
        console.error('Fetch friends error', error.response.data);
      }
    };
    fetchFriends();
  }, []);

  const removeFriend = async (friendId) => {
    try {
      await instance.delete(`api/user/friends/${friendId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setFriends(friends.filter(friend => friend.id !== friendId));
    } catch (error) {
      console.error('Remove friend error', error.response.data);
    }
  };

  return (
    <ul>
      {friends.length === 0 ? (
        <div className="no-requests-message">No Friends found</div>
      ) : (friends.map(friend => (
        <li key={friend.id}>
          {friend.name} - {friend.email}
          <button onClick={() => removeFriend(friend.id)}>Remove Friend</button>
        </li>
      )))}
    </ul>
  );
}

export default FriendList;