import React, { useState, useEffect } from 'react';
import instance from '../api/axios';

function FriendRequests() {
  const [requests, setRequests] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await instance.get('/api/user/friend-requests');
        setRequests(response.data);
      } catch (error) {
        setError('Failed to fetch friend requests.');
        console.error('Fetch requests error', error.response?.data);
      }
    };
    fetchRequests();
  }, []);

  const handleRequest = async (requestId, action) => {
    try {
      await instance.post(`/api/user/friend-requests/${requestId}/${action}`);
      setRequests(requests.filter(request => request.id !== requestId));
    } catch (error) {
      setError(`Failed to ${action} the request.`);
      console.error(`${action} request error`, error.response?.data);
    }
  };

  return (
    <div className="friend-requests-container">
      {error && <div className="error-message">{error}</div>}
      {requests.length === 0 ? (
        <div className="no-requests-message">No requests are available</div>
      ) : (
        <ul>
          {requests.map(request => (
            <li key={request.id} className="request-item">
              {request?.sender?.name} - {request?.sender?.email}
              <button onClick={() => handleRequest(request.id, 'accept')} className="accept-btn">Accept</button>
              <button onClick={() => handleRequest(request.id, 'reject')} className="reject-btn">Reject</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default FriendRequests;
