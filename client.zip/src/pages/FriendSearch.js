import React, { useState } from 'react';
import instance from '../api/axios';
import { ToastContainer,toast } from 'react-toastify';

function FriendSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [error, setError] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const response = await instance.get(`/api/user/search?query=${query}`);
      setResults(response.data);
      setError(null); // Clear previous errors
    } catch (error) {
      setError('Failed to fetch search results');
      console.error('Search error', error.response ? error.response.data : error);
    }
  };

  const sendFriendRequest = async (userId) => {
    try {
      await instance.post(`/api/user/friend-requests/${userId}`);
      toast.success("Friend request sent");
    } catch (error) {
      setError('Failed to send friend request');
      console.error('Send friend request error', error.response ? error.response.data : error);
    }
  };

  return (
    <>
      <div className="friend-search-container">
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleSearch}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search friends"
          />
          <button type="submit">Search</button>
        </form>
        <ul>
          {results.map(user => (
            <li key={user.id}>
              {user.name} - {user.email}
              <button onClick={() => sendFriendRequest(user.id)}>Send Friend Request</button>
            </li>
          ))}
        </ul>
      </div>
      <ToastContainer />
    </>

  );
}

export default FriendSearch;
