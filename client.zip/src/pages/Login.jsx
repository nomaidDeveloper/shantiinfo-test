import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import Logo from "../assets/logo1.svg";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { loginRoute } from "../utils/APIRoutes";

export default function Login() {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      identifier: "",
      password: "",
    },
  });
  const toastOptions = {
    position: "bottom-right",
    autoClose: 8000,
    pauseOnHover: true,
    draggable: true,
    theme: "dark",
  };

  useEffect(() => {
    if (localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY)) {
      navigate("/");
    }
  }, [navigate]);

  const isEmail = (input) => /\S+@\S+\.\S+/.test(input);

  const onSubmit = async (data) => {
    try {
      const { identifier, password } = data;
      const payload = isEmail(identifier) ? { email: identifier, password } : { mobile: identifier, password };

      const response = await axios.post(loginRoute, payload);

      if (response.data.status === false) {
        toast.error(response.data.msg, toastOptions);
      } else if (response.data.status === true) {
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('userId', response.data.user.id);
        localStorage.setItem(
          process.env.REACT_APP_LOCALHOST_KEY,
          JSON.stringify(response.data.user)
        );
        navigate("/");
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        toast.error(error.response.data.message, toastOptions);
      } else {
        toast.error("An unexpected error occurred. Please try again later.", toastOptions);
      }
      console.error("Login error:", error);
    }
  };

  return (
    <>
      <div className="centered-content">
        <div className="login-container">
          <form onSubmit={handleSubmit(onSubmit)}>
            <h1>Login</h1>
            <input
              type="text"
              placeholder="Email or phone number"
              {...register("identifier", { required: true, minLength: 3 })}
            />
            {errors.identifier && (
              <span className="error">Identifier is required (min. 3 characters).</span>
            )}
            <input
              type="password"
              placeholder="Password"
              {...register("password", { required: true, minLength: 8 })}
            />
            {errors.password && (
              <span className="error">Password is required (min. 8 characters).</span>
            )}

            <button type="submit">Login</button>
            <span className="footer">
              Already have an account? <Link to="/signup">Signup.</Link>
            </span>
            <span>
              <Link to="/forgotpassword">Forgot Password.</Link>
            </span>
          </form>
        </div>
      </div>
      <ToastContainer />
    </>
  );
}
