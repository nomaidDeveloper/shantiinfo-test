import React, { useState, useEffect } from 'react';
import instance from '../api/axios'; 

function Profile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const userId = localStorage.getItem('userId');
        if (userId) {
          const response = await instance.get(`/api/user/getUser/${userId}`);
          setProfile(response.data);
        }
      } catch (error) {
        setError('Failed to fetch profile');
        console.error('Fetch profile error', error.response ? error.response.data : error);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await instance.put('/api/user/updateUser', profile);
      alert('Profile updated successfully');
    } catch (error) {
      setError('Failed to update profile');
      console.error('Update profile error', error.response ? error.response.data : error);
    }
  };

  if (loading) return <div className="profile-container">Loading...</div>;
  if (error) return <div className="profile-container error-message">{error}</div>;

  return (
    <div className="profile-container">
      <h1>Update Profile</h1>
      <form onSubmit={handleUpdate}>
        <input
          type="text"
          value={profile.name || ''}
          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
          placeholder="Name"
          required
        />
        <input
          type="text"
          value={profile.address || ''}
          onChange={(e) => setProfile({ ...profile, address: e.target.value })}
          placeholder="Address"
        />
        <input
          type="number"
          step="any"
          value={profile.latitude || ''}
          onChange={(e) => setProfile({ ...profile, latitude: parseFloat(e.target.value) })}
          placeholder="Latitude"
        />
        <input
          type="number"
          step="any"
          value={profile.longitude || ''}
          onChange={(e) => setProfile({ ...profile, longitude: parseFloat(e.target.value) })}
          placeholder="Longitude"
        />
        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
}

export default Profile;
