import React, { useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { registerRoute } from "../utils/APIRoutes";
import NominatimAutocomplete from "../components/NominatimAutocomplete";

export default function Register() {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [address, setAddress] = useState('');
  const [coordinates, setCoordinates] = useState({ lat: null, lng: null });

  const toastOptions = {
    position: "bottom-right",
    autoClose: 8000,
    pauseOnHover: true,
    draggable: true,
    theme: "dark",
  };

  const handleValidation = (data) => {
    const { password, confirmPassword, name, email } = data;
    if (password.length < 6) {
      toast.error(
        "Password should be equal or greater than 6 characters.",
        toastOptions
      );
      return false;
    } else if (email === "") {
      toast.error("Email is required.", toastOptions);
      return false;
    } else if (!address || !coordinates.lat || !coordinates.lng) {
      toast.error("Address and coordinates are required.", toastOptions);
      return false;
    }
    return true;
  };

  const onSubmit = async (data) => {
    if (handleValidation(data)) {
      try {
        const { email, name, password, mobile } = data;
        const response = await axios.post(registerRoute, {
          name,
          email,
          mobile,
          password,
          address,
          latitude: coordinates.lat,
          longitude: coordinates.lng
        });

        if (response.data.status === false) {
          toast.error(response.data.msg, toastOptions);
        } else if (response.data.status === true) {
          localStorage.setItem('token', response.data.token);
          localStorage.setItem('userId', response.data.user.id);
          navigate("/");
        }
      } catch (error) {
        if (error.response && error.response.data && error.response.data.message) {
          toast.error(error.response.data.message, toastOptions);
        } else {
          toast.error("An unexpected error occurred. Please try again later.", toastOptions);
        }
        console.error("Registration error:", error);
      }
    }
  };

  const handleAddressSelect = ({ address, latitude, longitude }) => {
    setAddress(address);
    setCoordinates({ lat: latitude, lng: longitude });
  };

  return (
    <>
      <div className="centered-content">
        <div className="login-container">
          <form onSubmit={handleSubmit(onSubmit)}>
            <h1>Signup</h1>
            <input
              type="text"
              placeholder="Name"
              {...register("name", { required: true, minLength: 3 })}
            />
            {errors.name && (
              <span className="error">Name is required</span>
            )}
            <input
              type="email"
              placeholder="Email"
              {...register("email", { required: true })}
            />
            {errors.email && (
              <span className="error">Email is required.</span>
            )}
            <input
              type="text"
              placeholder="Mobile"
              {...register("mobile", { required: true })}
            />
            {errors.mobile && (
              <span className="error">Mobile is required.</span>
            )}
            <input
              type="password"
              placeholder="Password"
              {...register("password", { required: true, minLength: 8 })}
            />
            {errors.password && (
              <span className="error">Password is required (min. 8 characters).</span>
            )}

            <NominatimAutocomplete onSelect={handleAddressSelect} />

            <button type="submit">Create User</button>
            <span className="footer">
              Already have an account? <Link to="/login">Login.</Link>
            </span>
            <span>
              <Link to="/forgotpassword">Forgot Password.</Link>
            </span>
          </form>
        </div>
      </div>
      <ToastContainer />
    </>
  );
}


